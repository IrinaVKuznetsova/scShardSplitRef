#!/usr/bin/env Rscript

# ==============================================================================
# prepare_organellar_gtf.R
#
# Converts:
#   mt.gff3
#   pt.gff3
#
# into:
#   organellar.gtf
#
# compatible with Cell Ranger ARC.
#
# Usage:
#
# Rscript code/prepare_organellar_gtf.R \
#   data/mt.gff3 \
#   data/pt.gff3 \
#   data/organellar.gtf
#
# R dependencies:
#   install.packages("tidyverse")
#
# External dependency:
#   gffread
#
# Main functions:
#   1. convert GFF3 to GTF using gffread;
#   2. standardize seqnames as Mt and Pt;
#   3. normalize gene_id and transcript_id;
#   4. split reused transcripts into distinct loci;
#   5. reconstruct missing transcript records when necessary;
#   6. create missing exon records from CDS features;
#   7. number exons according to transcriptional direction;
#   8. assign CDS features to exons;
#   9. reconstruct gene records;
#  10. add biotype, source, exon_id, and protein_id;
#  11. validate the final GTF structure and write the output file.
# ==============================================================================


suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
  library(purrr)
  library(tibble)
})


# ==============================================================================
# 1. ARGUMENTS
# ==============================================================================

args <- commandArgs(
  trailingOnly = TRUE
)

if (length(args) != 3L) {
  stop(
    paste(
      "Usage:",
      "Rscript prepare_organellar_gtf.R",
      "mt.gff3",
      "pt.gff3",
      "organellar.gtf"
    ),
    call. = FALSE
  )
}

mt_gff3 <- path.expand(args[[1L]])
pt_gff3 <- path.expand(args[[2L]])
output_gtf <- path.expand(args[[3L]])


# ==============================================================================
# 2. CONSTANTS
# ==============================================================================

gtf_columns <- c(
  "seqname",
  "source",
  "feature",
  "start",
  "end",
  "score",
  "strand",
  "frame",
  "attribute"
)

allowed_features <- c(
  "gene",
  "transcript",
  "exon",
  "CDS"
)

feature_order <- c(
  gene = 1L,
  transcript = 2L,
  exon = 3L,
  CDS = 4L
)


# ==============================================================================
# 3. GENERAL FUNCTIONS
# ==============================================================================

assert_input_file <- function(path, label) {
  if (!file.exists(path)) {
    stop(
      label,
      " not found: ",
      path,
      call. = FALSE
    )
  }
  
  if (dir.exists(path)) {
    stop(
      label,
      " is a directory rather than a file: ",
      path,
      call. = FALSE
    )
  }
  
  invisible(path)
}


assert_program <- function(program) {
  program_path <- Sys.which(program)
  
  if (!nzchar(program_path)) {
    stop(
      "Required program not found in PATH: ",
      program,
      call. = FALSE
    )
  }
  
  invisible(program_path)
}


normalize_identifier <- function(x) {
  x |>
    as.character() |>
    str_trim() |>
    na_if("") |>
    na_if(".") |>
    str_replace_all("[[:space:]]+", "_") |>
    str_replace_all('[";\t\r\n]', "_")
}


first_non_missing <- function(
    x,
    default = NA_character_
) {
  values <- x[
    !is.na(x) &
      nzchar(as.character(x))
  ]
  
  if (length(values) == 0L) {
    default
  } else {
    as.character(values[[1L]])
  }
}


extract_gtf_attribute <- function(
    attribute,
    key
) {
  pattern <- paste0(
    "(?:^|;[[:space:]]*)",
    key,
    '[[:space:]]+"([^"]+)"'
  )
  
  str_match(
    attribute,
    pattern
  )[, 2L]
}


infer_gene_biotype <- function(
    gene_name,
    current_biotype = NA_character_,
    protein_id = NA_character_
) {
  current_biotype <- normalize_identifier(
    current_biotype
  )
  
  gene_name_lower <- str_to_lower(
    coalesce(
      gene_name,
      ""
    )
  )
  
  case_when(
    !is.na(current_biotype) &
      nzchar(current_biotype) ~
      current_biotype,
    
    str_detect(
      gene_name_lower,
      "^trn"
    ) ~ "tRNA",
    
    str_detect(
      gene_name_lower,
      "^rrn|ribosomal_rna|rrna"
    ) ~ "rRNA",
    
    str_detect(
      gene_name_lower,
      "pseudo|pseudogene"
    ) ~ "pseudogene",
    
    !is.na(protein_id) &
      nzchar(protein_id) ~
      "protein_coding",
    
    TRUE ~ "protein_coding"
  )
}


default_transcript_name <- function(
    gene_name,
    gene_biotype
) {
  case_when(
    gene_biotype %in% c(
      "tRNA",
      "rRNA",
      "ncRNA",
      "pseudogene"
    ) ~ gene_name,
    
    TRUE ~ paste0(
      gene_name,
      "-1"
    )
  )
}


read_gtf <- function(path) {
  read_tsv(
    file = path,
    col_names = gtf_columns,
    col_types = cols(
      seqname = col_character(),
      source = col_character(),
      feature = col_character(),
      start = col_double(),
      end = col_double(),
      score = col_character(),
      strand = col_character(),
      frame = col_character(),
      attribute = col_character()
    ),
    quote = "",
    na = character(),
    comment = "#",
    progress = FALSE,
    show_col_types = FALSE
  )
}


write_gtf <- function(
    gtf,
    path
) {
  output_lines <- gtf |>
    transmute(
      line = paste(
        seqname,
        source,
        feature,
        start,
        end,
        score,
        strand,
        frame,
        attribute,
        sep = "\t"
      )
    ) |>
    pull(line)
  
  writeLines(
    output_lines,
    con = path,
    useBytes = TRUE
  )
  
  invisible(path)
}


# ==============================================================================
# 4. GTF ATTRIBUTE FORMATTING
# ==============================================================================

format_gtf_field <- function(
    key,
    value
) {
  if (
    length(value) == 0L ||
    is.na(value) ||
    !nzchar(as.character(value))
  ) {
    return(NA_character_)
  }
  
  value <- as.character(value)
  
  if (str_detect(value, '[";\t\r\n]')) {
    stop(
      "Invalid value for GTF attribute ",
      key,
      ": ",
      value,
      call. = FALSE
    )
  }
  
  paste0(
    key,
    ' "',
    value,
    '"'
  )
}


format_gtf_attributes <- function(
    feature,
    gene_id,
    transcript_id = NA_character_,
    gene_name = NA_character_,
    gene_source = "ena",
    gene_biotype = "protein_coding",
    transcript_name = NA_character_,
    transcript_source = "ena",
    transcript_biotype = NA_character_,
    exon_number = NA_integer_,
    exon_id = NA_character_,
    protein_id = NA_character_,
    original_gene_id = NA_character_,
    original_transcript_id = NA_character_
) {
  if (
    is.na(gene_id) ||
    !nzchar(gene_id)
  ) {
    stop(
      "Cannot format a GTF row without gene_id.",
      call. = FALSE
    )
  }
  
  transcript_biotype <- coalesce(
    transcript_biotype,
    gene_biotype
  )
  
  fields <- c(
    format_gtf_field(
      "gene_id",
      gene_id
    )
  )
  
  if (feature != "gene") {
    fields <- c(
      fields,
      format_gtf_field(
        "transcript_id",
        transcript_id
      )
    )
  }
  
  if (!is.na(exon_number)) {
    fields <- c(
      fields,
      format_gtf_field(
        "exon_number",
        exon_number
      )
    )
  }
  
  fields <- c(
    fields,
    format_gtf_field(
      "gene_name",
      gene_name
    ),
    format_gtf_field(
      "gene_source",
      gene_source
    ),
    format_gtf_field(
      "gene_biotype",
      gene_biotype
    )
  )
  
  if (feature != "gene") {
    fields <- c(
      fields,
      format_gtf_field(
        "transcript_name",
        transcript_name
      ),
      format_gtf_field(
        "transcript_source",
        transcript_source
      ),
      format_gtf_field(
        "transcript_biotype",
        transcript_biotype
      )
    )
  }
  
  if (feature == "exon") {
    fields <- c(
      fields,
      format_gtf_field(
        "exon_id",
        exon_id
      )
    )
  }
  
  if (feature == "CDS") {
    fields <- c(
      fields,
      format_gtf_field(
        "protein_id",
        protein_id
      )
    )
  }
  
  fields <- c(
    fields,
    format_gtf_field(
      "original_gene_id",
      original_gene_id
    ),
    format_gtf_field(
      "original_transcript_id",
      original_transcript_id
    )
  )
  
  fields <- fields[!is.na(fields)]
  
  paste0(
    paste(
      fields,
      collapse = "; "
    ),
    ";"
  )
}


# ==============================================================================
# 5. GFF3 -> GTF CONVERSION WITH GFFREAD
# ==============================================================================

convert_gff3_with_gffread <- function(
    input_gff3,
    output_gtf,
    organelle_name
) {
  message(
    "Converting ",
    organelle_name,
    " GFF3 with gffread..."
  )
  
  status <- system2(
    command = "gffread",
    args = c(
      shQuote(input_gff3),
      "-T",
      "-o",
      shQuote(output_gtf)
    )
  )
  
  if (status != 0L) {
    stop(
      organelle_name,
      " GFF3-to-GTF conversion failed with exit status ",
      status,
      ".",
      call. = FALSE
    )
  }
  
  if (!file.exists(output_gtf)) {
    stop(
      organelle_name,
      " GTF was not created: ",
      output_gtf,
      call. = FALSE
    )
  }
  
  invisible(output_gtf)
}


# ==============================================================================
# 6. INITIAL IMPORT AND NORMALIZATION
# ==============================================================================

prepare_raw_gtf <- function(
    path,
    new_seqname
) {
  gtf <- read_gtf(path) |>
    mutate(
      seqname = new_seqname,
      
      source = if_else(
        is.na(source) |
          !nzchar(source),
        "ena",
        source
      ),
      
      row_id = row_number(),
      
      old_transcript_id = extract_gtf_attribute(
        attribute,
        "transcript_id"
      ) |>
        normalize_identifier(),
      
      old_gene_id = extract_gtf_attribute(
        attribute,
        "gene_id"
      ) |>
        normalize_identifier(),
      
      gene_name = extract_gtf_attribute(
        attribute,
        "gene_name"
      ) |>
        normalize_identifier(),
      
      transcript_name = extract_gtf_attribute(
        attribute,
        "transcript_name"
      ) |>
        normalize_identifier(),
      
      gene_biotype = coalesce(
        extract_gtf_attribute(
          attribute,
          "gene_biotype"
        ),
        extract_gtf_attribute(
          attribute,
          "gene_type"
        ),
        extract_gtf_attribute(
          attribute,
          "transcript_biotype"
        ),
        extract_gtf_attribute(
          attribute,
          "transcript_type"
        )
      ) |>
        normalize_identifier(),
      
      protein_id = extract_gtf_attribute(
        attribute,
        "protein_id"
      ) |>
        normalize_identifier(),
      
      original_exon_number = suppressWarnings(
        as.integer(
          extract_gtf_attribute(
            attribute,
            "exon_number"
          )
        )
      )
    )
  
  invalid_rows <- gtf |>
    filter(
      !feature %in% c(
        "gene",
        "transcript",
        "exon",
        "CDS"
      ) |
        is.na(start) |
        is.na(end) |
        start < 1 |
        end < start |
        !strand %in% c(
          "+",
          "-"
        )
    )
  
  if (nrow(invalid_rows) > 0L) {
    print(
      invalid_rows |>
        slice_head(n = 20L)
    )
    
    stop(
      "Invalid rows detected in ",
      new_seqname,
      " GTF.",
      call. = FALSE
    )
  }
  
  gtf
}


# ==============================================================================
# 7. BUILDING THE TRANSCRIPT TABLE
# ==============================================================================

build_transcript_table <- function(gtf) {
  transcript_rows <- gtf |>
    filter(
      feature == "transcript"
    )
  
  child_models <- gtf |>
    filter(
      feature %in% c(
        "exon",
        "CDS"
      ),
      !is.na(old_transcript_id),
      nzchar(old_transcript_id)
    ) |>
    group_by(
      seqname,
      source,
      strand,
      old_transcript_id
    ) |>
    summarise(
      start = min(start),
      end = max(end),
      
      old_gene_id = first_non_missing(
        old_gene_id,
        default = first(old_transcript_id)
      ),
      
      gene_name = first_non_missing(
        gene_name,
        default = first_non_missing(
          old_gene_id,
          default = first(old_transcript_id)
        )
      ),
      
      gene_biotype = first_non_missing(
        gene_biotype
      ),
      
      transcript_name = first_non_missing(
        transcript_name
      ),
      
      protein_id = first_non_missing(
        protein_id
      ),
      
      .groups = "drop"
    )
  
  existing_transcripts <- transcript_rows |>
    transmute(
      seqname,
      source,
      strand,
      old_transcript_id,
      start,
      end,
      
      old_gene_id = coalesce(
        old_gene_id,
        old_transcript_id
      ),
      
      gene_name = coalesce(
        gene_name,
        old_gene_id,
        old_transcript_id
      ),
      
      gene_biotype,
      transcript_name,
      protein_id
    )
  
  missing_transcripts <- child_models |>
    anti_join(
      existing_transcripts |>
        select(
          seqname,
          strand,
          old_transcript_id,
          start,
          end
        ),
      by = c(
        "seqname",
        "strand",
        "old_transcript_id",
        "start",
        "end"
      )
    )
  
  transcripts <- bind_rows(
    existing_transcripts,
    missing_transcripts
  ) |>
    filter(
      !is.na(old_transcript_id),
      nzchar(old_transcript_id)
    ) |>
    mutate(
      old_gene_id = coalesce(
        old_gene_id,
        old_transcript_id
      ),
      
      gene_name = coalesce(
        gene_name,
        old_gene_id
      ),
      
      gene_biotype = infer_gene_biotype(
        gene_name = gene_name,
        current_biotype = gene_biotype,
        protein_id = protein_id
      ),
      
      transcript_name = coalesce(
        transcript_name,
        default_transcript_name(
          gene_name,
          gene_biotype
        )
      )
    ) |>
    distinct(
      seqname,
      strand,
      old_transcript_id,
      start,
      end,
      .keep_all = TRUE
    ) |>
    arrange(
      old_transcript_id,
      seqname,
      strand,
      start,
      end
    ) |>
    group_by(
      old_transcript_id
    ) |>
    mutate(
      locus_number = row_number(),
      number_of_loci = n(),
      
      locus_suffix = if_else(
        number_of_loci > 1L,
        paste0(
          "_locus",
          locus_number
        ),
        ""
      ),
      
      transcript_id = paste0(
        old_transcript_id,
        locus_suffix
      ),
      
      gene_id = paste0(
        old_gene_id,
        locus_suffix
      )
    ) |>
    ungroup() |>
    select(
      old_transcript_id,
      old_gene_id,
      transcript_id,
      gene_id,
      gene_name,
      gene_biotype,
      transcript_name,
      protein_id,
      seqname,
      source,
      start,
      end,
      strand,
      locus_number,
      number_of_loci
    )
  
  if (nrow(transcripts) == 0L) {
    stop(
      "No transcript models could be reconstructed.",
      call. = FALSE
    )
  }
  
  duplicated_transcripts <- transcripts |>
    count(
      transcript_id
    ) |>
    filter(
      n > 1L
    )
  
  if (nrow(duplicated_transcripts) > 0L) {
    print(duplicated_transcripts)
    
    stop(
      "Transcript IDs are duplicated after locus normalization.",
      call. = FALSE
    )
  }
  
  transcripts
}


# ==============================================================================
# 8. ASSIGNING FEATURES TO LOCI
# ==============================================================================

assign_locus <- function(
    row_id,
    seqname,
    feature,
    start,
    end,
    strand,
    old_transcript_id,
    old_gene_id,
    gene_name,
    transcripts
) {
  if (
    is.na(old_transcript_id) ||
    !nzchar(old_transcript_id)
  ) {
    stop(
      "Row ",
      row_id,
      " (",
      feature,
      " ",
      seqname,
      ":",
      start,
      "-",
      end,
      ") has no transcript_id.",
      call. = FALSE
    )
  }
  
  hits <- transcripts |>
    filter(
      .data$old_transcript_id ==
        .env$old_transcript_id,
      
      .data$seqname ==
        .env$seqname,
      
      .data$strand ==
        .env$strand,
      
      .data$start <=
        .env$start,
      
      .data$end >=
        .env$end
    )
  
  if (nrow(hits) > 1L) {
    hits <- hits |>
      mutate(
        locus_width =
          .data$end -
          .data$start +
          1,
        
        coordinate_distance =
          abs(
            .data$start -
              .env$start
          ) +
          abs(
            .data$end -
              .env$end
          )
      ) |>
      arrange(
        locus_width,
        coordinate_distance,
        start,
        end
      ) |>
      slice_head(n = 1L)
  }
  
  if (nrow(hits) == 0L) {
    stop(
      "Could not assign row ",
      row_id,
      " (",
      feature,
      " ",
      seqname,
      ":",
      start,
      "-",
      end,
      ", transcript_id=",
      old_transcript_id,
      ") to a transcript locus.",
      call. = FALSE
    )
  }
  
  tibble(
    row_id = row_id,
    
    transcript_id =
      hits$transcript_id[[1L]],
    
    gene_id =
      hits$gene_id[[1L]],
    
    resolved_gene_name = coalesce(
      gene_name,
      hits$gene_name[[1L]],
      old_gene_id,
      hits$gene_id[[1L]]
    ),
    
    resolved_gene_biotype =
      hits$gene_biotype[[1L]],
    
    resolved_transcript_name =
      hits$transcript_name[[1L]],
    
    resolved_protein_id =
      hits$protein_id[[1L]],
    
    resolved_source =
      hits$source[[1L]],
    
    original_gene_id =
      hits$old_gene_id[[1L]],
    
    original_transcript_id =
      hits$old_transcript_id[[1L]]
  )
}


assign_all_loci <- function(
    gtf,
    transcripts
) {
  rows_to_assign <- gtf |>
    filter(
      feature != "gene"
    ) |>
    select(
      row_id,
      seqname,
      feature,
      start,
      end,
      strand,
      old_transcript_id,
      old_gene_id,
      gene_name
    )
  
  pmap_dfr(
    rows_to_assign,
    \(row_id,
      seqname,
      feature,
      start,
      end,
      strand,
      old_transcript_id,
      old_gene_id,
      gene_name) {
      
      assign_locus(
        row_id = row_id,
        seqname = seqname,
        feature = feature,
        start = start,
        end = end,
        strand = strand,
        old_transcript_id =
          old_transcript_id,
        old_gene_id =
          old_gene_id,
        gene_name =
          gene_name,
        transcripts =
          transcripts
      )
    }
  )
}


# ==============================================================================
# 9. BUILDING NORMALIZED FEATURES
# ==============================================================================

build_fixed_child_rows <- function(
    gtf,
    assignment
) {
  gtf |>
    filter(
      feature != "gene"
    ) |>
    left_join(
      assignment,
      by = "row_id"
    ) |>
    mutate(
      source = resolved_source,
      gene_name = resolved_gene_name,
      gene_biotype =
        resolved_gene_biotype,
      transcript_name =
        resolved_transcript_name,
      protein_id = coalesce(
        protein_id,
        resolved_protein_id
      )
    ) |>
    select(
      all_of(gtf_columns),
      row_id,
      old_transcript_id,
      old_gene_id,
      transcript_id,
      gene_id,
      gene_name,
      gene_biotype,
      transcript_name,
      protein_id,
      original_gene_id,
      original_transcript_id
    )
}


# ==============================================================================
# 10. CREATING MISSING EXON RECORDS
# ==============================================================================

add_missing_exons <- function(
    fixed_rows
) {
  transcripts_with_exons <- fixed_rows |>
    filter(
      feature == "exon"
    ) |>
    distinct(
      transcript_id
    )
  
  cds_without_exons <- fixed_rows |>
    filter(
      feature == "CDS"
    ) |>
    anti_join(
      transcripts_with_exons,
      by = "transcript_id"
    )
  
  if (nrow(cds_without_exons) == 0L) {
    return(fixed_rows)
  }
  
  plus_exons <- cds_without_exons |>
    filter(
      strand == "+"
    ) |>
    group_by(
      seqname,
      source,
      strand,
      transcript_id,
      gene_id,
      gene_name,
      gene_biotype,
      transcript_name,
      original_gene_id,
      original_transcript_id
    ) |>
    arrange(
      start,
      end,
      .by_group = TRUE
    ) |>
    ungroup()
  
  minus_exons <- cds_without_exons |>
    filter(
      strand == "-"
    ) |>
    group_by(
      seqname,
      source,
      strand,
      transcript_id,
      gene_id,
      gene_name,
      gene_biotype,
      transcript_name,
      original_gene_id,
      original_transcript_id
    ) |>
    arrange(
      desc(start),
      desc(end),
      .by_group = TRUE
    ) |>
    ungroup()
  
  new_exons <- bind_rows(
    plus_exons,
    minus_exons
  ) |>
    mutate(
      feature = "exon",
      frame = ".",
      score = ".",
      protein_id = NA_character_,
      row_id = NA_integer_
    ) |>
    select(
      all_of(gtf_columns),
      row_id,
      old_transcript_id,
      old_gene_id,
      transcript_id,
      gene_id,
      gene_name,
      gene_biotype,
      transcript_name,
      protein_id,
      original_gene_id,
      original_transcript_id
    )
  
  bind_rows(
    fixed_rows,
    new_exons
  )
}


# ==============================================================================
# 11. NUMBERING EXON RECORDS
# ==============================================================================

number_exons <- function(
    fixed_rows
) {
  exon_rows <- fixed_rows |>
    filter(
      feature == "exon"
    )
  
  plus_exons <- exon_rows |>
    filter(
      strand == "+"
    ) |>
    group_by(
      transcript_id
    ) |>
    arrange(
      start,
      end,
      .by_group = TRUE
    ) |>
    mutate(
      exon_number = row_number()
    ) |>
    ungroup()
  
  minus_exons <- exon_rows |>
    filter(
      strand == "-"
    ) |>
    group_by(
      transcript_id
    ) |>
    arrange(
      desc(start),
      desc(end),
      .by_group = TRUE
    ) |>
    mutate(
      exon_number = row_number()
    ) |>
    ungroup()
  
  numbered_exons <- bind_rows(
    plus_exons,
    minus_exons
  ) |>
    mutate(
      exon_id = paste0(
        transcript_id,
        "-",
        exon_number
      )
    ) |>
    select(
      row_id,
      seqname,
      strand,
      transcript_id,
      start,
      end,
      exon_number,
      exon_id
    )
  
  non_exons <- fixed_rows |>
    filter(
      feature != "exon"
    ) |>
    mutate(
      exon_number = NA_integer_,
      exon_id = NA_character_
    )
  
  exon_features <- fixed_rows |>
    filter(
      feature == "exon"
    ) |>
    select(
      -any_of(
        c(
          "exon_number",
          "exon_id"
        )
      )
    ) |>
    left_join(
      numbered_exons,
      by = c(
        "row_id",
        "seqname",
        "strand",
        "transcript_id",
        "start",
        "end"
      )
    )
  
  bind_rows(
    non_exons,
    exon_features
  )
}


# ==============================================================================
# 12. ASSIGNING CDS FEATURES TO EXONS
# ==============================================================================

assign_cds_to_exons <- function(
    fixed_rows
) {
  exons <- fixed_rows |>
    filter(
      feature == "exon"
    ) |>
    select(
      transcript_id,
      exon_number,
      exon_id,
      exon_start = start,
      exon_end = end
    )
  
  cds <- fixed_rows |>
    filter(
      feature == "CDS"
    ) |>
    select(
      -exon_number,
      -exon_id
    ) |>
    left_join(
      exons,
      by = "transcript_id",
      relationship = "many-to-many"
    ) |>
    filter(
      start >= exon_start,
      end <= exon_end
    ) |>
    group_by(
      row_id
    ) |>
    slice_min(
      order_by =
        exon_end -
        exon_start,
      n = 1L,
      with_ties = FALSE
    ) |>
    ungroup() |>
    select(
      -exon_start,
      -exon_end
    )
  
  unassigned_cds <- fixed_rows |>
    filter(
      feature == "CDS"
    ) |>
    anti_join(
      cds |>
        distinct(row_id),
      by = "row_id"
    )
  
  if (nrow(unassigned_cds) > 0L) {
    print(
      unassigned_cds |>
        select(
          seqname,
          start,
          end,
          strand,
          transcript_id
        ) |>
        slice_head(n = 20L)
    )
    
    stop(
      "Some CDS records could not be assigned to an exon.",
      call. = FALSE
    )
  }
  
  non_cds <- fixed_rows |>
    filter(
      feature != "CDS"
    )
  
  bind_rows(
    non_cds,
    cds
  )
}


# ==============================================================================
# 13. FORMATTING CHILD FEATURES
# ==============================================================================

format_child_attributes <- function(
    fixed_rows
) {
  fixed_rows |>
    mutate(
      attribute = pmap_chr(
        list(
          feature,
          gene_id,
          transcript_id,
          gene_name,
          source,
          gene_biotype,
          transcript_name,
          exon_number,
          exon_id,
          protein_id,
          original_gene_id,
          original_transcript_id
        ),
        \(feature,
          gene_id,
          transcript_id,
          gene_name,
          source,
          gene_biotype,
          transcript_name,
          exon_number,
          exon_id,
          protein_id,
          original_gene_id,
          original_transcript_id) {
          
          format_gtf_attributes(
            feature = feature,
            gene_id = gene_id,
            transcript_id =
              transcript_id,
            gene_name =
              gene_name,
            gene_source =
              source,
            gene_biotype =
              gene_biotype,
            transcript_name =
              transcript_name,
            transcript_source =
              source,
            transcript_biotype =
              gene_biotype,
            exon_number =
              exon_number,
            exon_id =
              exon_id,
            protein_id =
              protein_id,
            original_gene_id =
              original_gene_id,
            original_transcript_id =
              original_transcript_id
          )
        }
      )
    )
}


# ==============================================================================
# 14. BUILDING GENE RECORDS
# ==============================================================================

build_gene_rows <- function(fixed_rows) {

  fixed_rows |>
    group_by(
      seqname,
      gene_id
    ) |>
    summarise(
      source = first(source),

      start = min(start),
      end   = max(end),

      strand = first(strand),

      gene_name =
        first_non_missing(gene_name),

      gene_biotype =
        first_non_missing(gene_biotype),

      original_gene_id =
        first_non_missing(original_gene_id),

      .groups = "drop"
    ) |>

    transmute(

      seqname,
      source,

      feature = "gene",

      start,
      end,

      score = ".",
      strand,
      frame = ".",

      attribute = pmap_chr(

        list(
          gene_id,
          gene_name,
          source,
          gene_biotype,
          original_gene_id
        ),

        \(gene_id,
          gene_name,
          source,
          gene_biotype,
          original_gene_id) {

          format_gtf_attributes(

            feature = "gene",

            gene_id = gene_id,

            gene_name = gene_name,

            gene_source = source,

            gene_biotype = gene_biotype,

            original_gene_id = original_gene_id
          )

        }

      )

    )

}

# ==============================================================================
# 15. VALIDATING THE FINAL GTF
# ==============================================================================

validate_final_gtf <- function(
    final_gtf
) {
  invalid_rows <- final_gtf |>
    filter(
      !feature %in%
        allowed_features |
        is.na(start) |
        is.na(end) |
        start < 1 |
        end < start |
        !strand %in% c(
          "+",
          "-"
        )
    )
  
  if (nrow(invalid_rows) > 0L) {
    print(
      invalid_rows |>
        slice_head(n = 20L)
    )
    
    stop(
      "Invalid rows detected in the final GTF.",
      call. = FALSE
    )
  }
  
  check <- final_gtf |>
    mutate(
      parsed_gene_id =
        extract_gtf_attribute(
          attribute,
          "gene_id"
        ),
      
      parsed_transcript_id =
        extract_gtf_attribute(
          attribute,
          "transcript_id"
        ),
      
      parsed_exon_number =
        extract_gtf_attribute(
          attribute,
          "exon_number"
        ),
      
      parsed_exon_id =
        extract_gtf_attribute(
          attribute,
          "exon_id"
        )
    )
  
  missing_gene_id <- check |>
    filter(
      is.na(parsed_gene_id) |
        !nzchar(parsed_gene_id)
    )
  
  if (nrow(missing_gene_id) > 0L) {
    print(
      missing_gene_id |>
        slice_head(n = 20L)
    )
    
    stop(
      nrow(missing_gene_id),
      " final GTF rows are missing gene_id.",
      call. = FALSE
    )
  }
  
  missing_transcript_id <- check |>
    filter(
      feature != "gene",
      is.na(parsed_transcript_id) |
        !nzchar(parsed_transcript_id)
    )
  
  if (nrow(missing_transcript_id) > 0L) {
    print(
      missing_transcript_id |>
        slice_head(n = 20L)
    )
    
    stop(
      nrow(missing_transcript_id),
      " non-gene rows are missing transcript_id.",
      call. = FALSE
    )
  }
  
  missing_exon_metadata <- check |>
    filter(
      feature == "exon",
      is.na(parsed_exon_number) |
        is.na(parsed_exon_id)
    )
  
  if (nrow(missing_exon_metadata) > 0L) {
    print(
      missing_exon_metadata |>
        slice_head(n = 20L)
    )
    
    stop(
      "Some exon rows lack exon_number or exon_id.",
      call. = FALSE
    )
  }
  
  duplicated_transcripts <- check |>
    filter(
      feature == "transcript"
    ) |>
    count(
      parsed_transcript_id
    ) |>
    filter(
      n > 1L
    )
  
  if (nrow(duplicated_transcripts) > 0L) {
    print(duplicated_transcripts)
    
    stop(
      "The final GTF contains duplicated transcript records.",
      call. = FALSE
    )
  }
  
  cds_without_exon <- check |>
    filter(
      feature == "CDS"
    ) |>
    distinct(
      parsed_transcript_id
    ) |>
    anti_join(
      check |>
        filter(
          feature == "exon"
        ) |>
        distinct(
          parsed_transcript_id
        ),
      by = "parsed_transcript_id"
    )
  
  if (nrow(cds_without_exon) > 0L) {
    print(cds_without_exon)
    
    stop(
      "Some CDS-containing transcripts have no exon.",
      call. = FALSE
    )
  }
  
  inconsistent_transcripts <- check |>
    filter(
      feature != "gene"
    ) |>
    group_by(
      parsed_transcript_id
    ) |>
    summarise(
      n_gene_ids =
        n_distinct(
          parsed_gene_id
        ),
      
      n_seqnames =
        n_distinct(
          seqname
        ),
      
      n_strands =
        n_distinct(
          strand
        ),
      
      .groups = "drop"
    ) |>
    filter(
      n_gene_ids != 1L |
        n_seqnames != 1L |
        n_strands != 1L
    )
  
  if (nrow(inconsistent_transcripts) > 0L) {
    print(inconsistent_transcripts)
    
    stop(
      "Some transcripts are associated with multiple genes, ",
      "seqnames or strands.",
      call. = FALSE
    )
  }
  
  transcript_limits <- check |>
    filter(
      feature == "transcript"
    ) |>
    transmute(
      parsed_transcript_id,
      transcript_start = start,
      transcript_end = end
    )
  
  outside_features <- check |>
    filter(
      feature %in% c(
        "exon",
        "CDS"
      )
    ) |>
    left_join(
      transcript_limits,
      by = "parsed_transcript_id"
    ) |>
    filter(
      start < transcript_start |
        end > transcript_end
    )
  
  if (nrow(outside_features) > 0L) {
    print(
      outside_features |>
        slice_head(n = 20L)
    )
    
    stop(
      "Some child features fall outside their transcript interval.",
      call. = FALSE
    )
  }
  
  invalid_cds_frames <- check |>
    filter(
      feature == "CDS",
      !frame %in% c(
        "0",
        "1",
        "2"
      )
    )
  
  if (nrow(invalid_cds_frames) > 0L) {
    print(
      invalid_cds_frames |>
        slice_head(n = 20L)
    )
    
    stop(
      "Some CDS rows have an invalid frame.",
      call. = FALSE
    )
  }
  
  if (
    any(
      str_detect(
        final_gtf$attribute,
        '""'
      )
    )
  ) {
    stop(
      "Duplicated quotation marks were detected in attributes.",
      call. = FALSE
    )
  }
  
  invisible(TRUE)
}


validate_written_gtf <- function(path) {
  lines <- readLines(
    path,
    warn = FALSE
  )
  
  if (length(lines) == 0L) {
    stop(
      "The written GTF is empty.",
      call. = FALSE
    )
  }
  
  field_counts <- str_split(
    lines,
    "\t"
  ) |>
    lengths()
  
  invalid_field_counts <- which(
    field_counts != 9L
  )
  
  if (
    length(
      invalid_field_counts
    ) > 0L
  ) {
    stop(
      "Rows with a number of columns other than nine: ",
      paste(
        head(
          invalid_field_counts,
          20L
        ),
        collapse = ", "
      ),
      call. = FALSE
    )
  }
  
  written_gtf <- read_gtf(path)
  
  validate_final_gtf(
    written_gtf
  )
  
  invisible(written_gtf)
}


# ==============================================================================
# 16. EXECUTION
# ==============================================================================

assert_input_file(
  mt_gff3,
  "Mitochondrial GFF3"
)

assert_input_file(
  pt_gff3,
  "Plastid GFF3"
)

assert_program(
  "gffread"
)

output_directory <- dirname(
  output_gtf
)

dir.create(
  output_directory,
  recursive = TRUE,
  showWarnings = FALSE
)

mt_raw_gtf <- file.path(
  output_directory,
  "mt_gffread_raw.gtf"
)

pt_raw_gtf <- file.path(
  output_directory,
  "pt_gffread_raw.gtf"
)


# ------------------------------------------------------------------------------
# Initial conversion
# ------------------------------------------------------------------------------

convert_gff3_with_gffread(
  input_gff3 = mt_gff3,
  output_gtf = mt_raw_gtf,
  organelle_name = "mitochondrial"
)

convert_gff3_with_gffread(
  input_gff3 = pt_gff3,
  output_gtf = pt_raw_gtf,
  organelle_name = "plastid"
)


# ------------------------------------------------------------------------------
# Importing and standardizing seqnames
# ------------------------------------------------------------------------------

message(
  "Importing and standardizing organellar GTF files..."
)

mt_gtf <- prepare_raw_gtf(
  mt_raw_gtf,
  new_seqname = "Mt"
)

pt_gtf <- prepare_raw_gtf(
  pt_raw_gtf,
  new_seqname = "Pt"
)

raw_organellar_gtf <- bind_rows(
  mt_gtf,
  pt_gtf
) |>
  mutate(
    row_id = row_number()
  )


# ------------------------------------------------------------------------------
# Transcript normalization
# ------------------------------------------------------------------------------

message(
  "Normalizing transcript loci..."
)

transcripts <- build_transcript_table(
  raw_organellar_gtf
)

message(
  "Transcript loci: ",
  nrow(transcripts)
)


# ------------------------------------------------------------------------------
# Assigning features to loci
# ------------------------------------------------------------------------------

message(
  "Assigning features to transcript loci..."
)

assignment <- assign_all_loci(
  gtf = raw_organellar_gtf,
  transcripts = transcripts
)

fixed_rows <- build_fixed_child_rows(
  gtf = raw_organellar_gtf,
  assignment = assignment
)


# ------------------------------------------------------------------------------
# Creating and numbering exon records
# ------------------------------------------------------------------------------

message(
  "Creating missing exon records..."
)

fixed_rows <- add_missing_exons(
  fixed_rows
)

message(
  "Numbering exon records..."
)

fixed_rows <- number_exons(
  fixed_rows
)

message(
  "Assigning CDS records to exon records..."
)

fixed_rows <- assign_cds_to_exons(
  fixed_rows
)


# ------------------------------------------------------------------------------
# Formatting child features
# ------------------------------------------------------------------------------

message(
  "Formatting transcript, exon and CDS attributes..."
)

fixed_rows <- format_child_attributes(
  fixed_rows
)


# ------------------------------------------------------------------------------
# Building gene records
# ------------------------------------------------------------------------------

message(
  "Rebuilding gene records..."
)

gene_rows <- build_gene_rows(
  fixed_rows
)

# ------------------------------------------------------------------------------
# Building the final GTF
# ------------------------------------------------------------------------------

final_gtf <- bind_rows(
  fixed_rows |>
    select(
      all_of(gtf_columns)
    ),
  gene_rows |>
    select(
      all_of(gtf_columns)
    )
) |>
  mutate(
    start = as.integer(
      round(start)
    ),
    
    end = as.integer(
      round(end)
    ),
    
    seq_order = case_when(
      seqname == "Mt" ~ 1L,
      seqname == "Pt" ~ 2L,
      TRUE ~ 99L
    ),
    
    feature_order_value =
      unname(
        feature_order[feature]
      ),
    
    feature_order_value =
      coalesce(
        feature_order_value,
        99L
      ),
    
    parsed_gene_id =
      extract_gtf_attribute(
        attribute,
        "gene_id"
      ),
    
    parsed_transcript_id =
      extract_gtf_attribute(
        attribute,
        "transcript_id"
      ),
    
    transcript_sort = coalesce(
      parsed_transcript_id,
      ""
    )
  ) |>
  arrange(
    seq_order,
    parsed_gene_id,
    transcript_sort,
    feature_order_value,
    start,
    end,
    strand
  ) |>
  distinct(
    seqname,
    source,
    feature,
    start,
    end,
    score,
    strand,
    frame,
    attribute,
    .keep_all = TRUE
  ) |>
  select(
    all_of(gtf_columns)
  )


# ------------------------------------------------------------------------------
# Validation and writing
# ------------------------------------------------------------------------------

message(
  "Validating final organellar GTF..."
)

validate_final_gtf(
  final_gtf
)

write_gtf(
  final_gtf,
  output_gtf
)

written_gtf <- validate_written_gtf(
  output_gtf
)


# ==============================================================================
# 18. FINAL REPORT
# ==============================================================================

message(
  "Written: ",
  output_gtf
)

message(
  "Rows: ",
  nrow(final_gtf)
)

message(
  "Mt rows: ",
  sum(
    final_gtf$seqname == "Mt"
  )
)

message(
  "Pt rows: ",
  sum(
    final_gtf$seqname == "Pt"
  )
)

message(
  "Genes: ",
  sum(
    final_gtf$feature == "gene"
  )
)

message(
  "Transcripts: ",
  sum(
    final_gtf$feature == "transcript"
  )
)

message(
  "Exons: ",
  sum(
    final_gtf$feature == "exon"
  )
)

message(
  "CDS: ",
  sum(
    final_gtf$feature == "CDS"
  )
)

message(
  "Feature summary:"
)

print(
  written_gtf |>
    count(
      seqname,
      feature,
      name = "n"
    )
)

message(
  "Gene biotype summary:"
)

print(
  written_gtf |>
    filter(feature == "gene") |>
    mutate(
      gene_id = extract_gtf_attribute(
        attribute,
        "gene_id"
      ),
      
      gene_biotype = extract_gtf_attribute(
        attribute,
        "gene_biotype"
      )
    ) |>
    distinct(
      seqname,
      gene_id,
      gene_biotype
    ) |>
    count(
      seqname,
      gene_biotype,
      name = "genes"
    )
)

message(
  "Intermediate files:"
)

message(
  "  ",
  mt_raw_gtf
)

message(
  "  ",
  pt_raw_gtf
)
